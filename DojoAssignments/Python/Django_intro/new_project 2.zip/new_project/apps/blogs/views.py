from django.shortcuts import render, HttpResponse, redirect


def index(request):
    response = "placeholder to later display all the list of blogs"
    request.session['blogName'] = "Esther's Test Blog"
    print ("*"*150, request.session['blogName'])
    return render(request, "blogs/index.html")

def new(request):
    response = "placeholder to display a new form to create a new blog"
    return HttpResponse(response)

def create(request):
    request.session['blogName'] = request.POST['blog-name']
    return redirect('/')

def show(request, blogNum):
    response = "placeholder to display blog " + str(blogNum)
    return HttpResponse(response)

def edit(request, blogNum):
    response = "placeholder for editing blog " + str(blogNum)
    return HttpResponse(response)

def destroy(request,blogNum):
    return redirect('/')
