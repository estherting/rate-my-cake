from django.apps import AppConfig


class RandomWordConfig(AppConfig):
    name = 'random_word'
